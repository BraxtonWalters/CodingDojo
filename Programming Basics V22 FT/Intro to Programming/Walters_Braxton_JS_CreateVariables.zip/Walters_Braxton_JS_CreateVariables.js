// Setting the minimum height requirement var
const minHeight = 42;
// Setting the minimum age requirement var
const minAge = 10;
