// We would need to count up to 6
// Start the loop with the iter val set to 2
// The loop should stop at 6, since its the last piece of candy to dispense
// The loop iterating var
// a var for the loop and for the runners speed

// init the runners speed var
let runnersSpeed = 5.5;

// create a loop that increments by 2 and starts at 2
for (let i = 2; i <= 6; i += 2) {
  // condit for checking the runners speed
  if (runnersSpeed >= 5.5) {
    console.log("Dispening Candy");
  }
}

// I wasn't sure if I should have gave out candy at 6 or stopped.
