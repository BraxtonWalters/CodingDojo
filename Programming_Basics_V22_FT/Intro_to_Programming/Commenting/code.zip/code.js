// var for keeping count og likes
var likeCount = 0;
// func increasing the like counter var
function increaseLikes() {
  // Inceasing the counter var by 1
  likeCount = likeCount + 1;
}
