


// check for key words that would identify if the paragraph is in first, second, or third person.

// create a function that takes one argument called str
// check the str for 1st person words
// if str contains those keywords identify it as 1st person
// if that checks false check for words that would identify it as 2nd person
// if both return false identify the str as 3rd person

// The hardest part would be ruling out edge cases. for instance if there is a quote with the word I inside a str that written in the 3rd person. Also, someone saying hers/his isn't uncommon in 1st person. 
